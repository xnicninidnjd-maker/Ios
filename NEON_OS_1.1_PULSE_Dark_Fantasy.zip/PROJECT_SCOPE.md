# 300-point scope map

The requested 300 features are grouped into these modules:
1. Core shell: boot, lock, home, widgets, dock, gestures, safe areas.
2. System UI: apps, search, notifications, quick settings surfaces.
3. Settings: personalization, display, sound, notifications, security, applications, storage, system, about, performance profiles.
4. Media: Files, Gallery, Music.
5. Network/productivity: Browser, Terminal, AI.
6. Store: catalog, real APK gate, official Play Market handoff.
7. Games: NEON Games + NEON: DARKNESS.
8. Reliability: permission-aware states, resource fallback, local persistence, modular separation.
9. Android packaging: Gradle app, manifest, native launcher Activity, WebView asset.
