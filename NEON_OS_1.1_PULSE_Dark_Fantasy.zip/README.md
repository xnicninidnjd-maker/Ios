# NEON OS 1.1 PULSE — Dark Fantasy Edition

Android-first NEON OS shell packaged as a native Android WebView application.

## What is real
- Native Android launcher Activity + WebView.
- Local HTML/CSS/JS UI with persistent settings via localStorage.
- Safe local terminal commands only.
- Explicit external Play Market handoff; no fake Play Market.
- NEON Store refuses to claim installation without a real APK/install bridge.
- NEON Files/Gallery expose permission-aware placeholder surfaces instead of pretending to access private storage.
- Embedded NEON: DARKNESS prototype with touch joystick, attack/interact/jump/pause and local game state.
- Responsive/safe-area-aware UI, dark fantasy/cyberpunk visual system, startup animation, lock screen, widgets, app grid, notifications, settings, wallpaper selector, AI shell, browser handoff.

## Build
1. Install Android Studio.
2. Open this folder as a Gradle project.
3. Let Gradle download Android Gradle Plugin and AndroidX WebKit.
4. Build > Build APK(s), or run:
   `./gradlew assembleDebug`
5. APK output:
   `app/build/outputs/apk/debug/app-debug.apk`

The repository intentionally does not claim that an APK has already been built.

## Next native bridges
For a production launcher, add:
- Storage Access Framework bridge for NEON Files.
- Android MediaStore bridge for Gallery/Music.
- PackageManager bridge for installed apps.
- Notification listener only with explicit user-granted permission.
- Real settings intents for Wi-Fi/Bluetooth/brightness where Android allows them.
- A dedicated Godot/Unity module for full 3D NEON: DARKNESS.
- A secure AI provider connector if remote AI is desired.

No passwords, Android security bypasses, hidden collection, or fake system changes are included.
