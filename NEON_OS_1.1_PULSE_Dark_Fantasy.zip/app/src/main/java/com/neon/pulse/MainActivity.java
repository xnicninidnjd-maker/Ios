package com.neon.pulse;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        Window w = getWindow();
        w.setStatusBarColor(android.graphics.Color.rgb(5,4,10));
        w.setNavigationBarColor(android.graphics.Color.rgb(5,4,10));
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = w.getInsetsController();
            if (c != null) c.setSystemBarsAppearance(0, WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS);
        }
        WebView v = new WebView(this);
        v.setBackgroundColor(android.graphics.Color.rgb(5,4,10));
        WebSettings s = v.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        v.setWebViewClient(new WebViewClient());
        v.setWebChromeClient(new WebChromeClient());
        v.loadUrl("file:///android_asset/index.html");
        setContentView(v);
    }
    @Override public void onBackPressed() {
        WebView v = (WebView)findViewById(android.R.id.content);
        super.onBackPressed();
    }
}
