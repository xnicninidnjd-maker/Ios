package com.neonos.launcher;

import android.app.Activity;
import android.Manifest;
import android.content.pm.PackageManager;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.BatteryManager;
import android.util.Base64;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView web;
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech textToSpeech;
    private boolean ttsReady = false;
    private static final int REQUEST_AUDIO_PERMISSION = 2001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        enableImmersiveFullscreen();

        textToSpeech = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = textToSpeech.setLanguage(new Locale("ru", "RU"));
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED;
            }
        });

        web = new WebView(this);
        web.setBackgroundColor(0xFF080A12);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setMediaPlaybackRequiresUserGesture(true);

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new LauncherBridge(), "NeonAndroid");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    /** Hide Android status/navigation bars so NEON OS fills the whole display. */
    private void enableImmersiveFullscreen() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) enableImmersiveFullscreen();
    }

    public class LauncherBridge {
        @JavascriptInterface
        public void startVoiceRecognition() {
            runOnUiThread(() -> {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO_PERMISSION);
                    return;
                }
                beginVoiceRecognition();
            });
        }

        @JavascriptInterface
        public void speak(String text) {
            if (text == null) return;
            final String safeText = text.length() > 350 ? text.substring(0, 350) : text;
            runOnUiThread(() -> {
                if (textToSpeech != null && ttsReady) {
                    textToSpeech.speak(safeText, TextToSpeech.QUEUE_FLUSH, null, "NEON_OS_TTS");
                }
            });
        }

        @JavascriptInterface
        public String listApps() {
            JSONArray result = new JSONArray();
            try {
                Intent intent = new Intent(Intent.ACTION_MAIN, null);
                intent.addCategory(Intent.CATEGORY_LAUNCHER);
                PackageManager pm = getPackageManager();
                List<ResolveInfo> apps = pm.queryIntentActivities(intent, 0);
                for (ResolveInfo item : apps) {
                    JSONObject app = new JSONObject();
                    app.put("label", item.loadLabel(pm).toString());
                    app.put("packageName", item.activityInfo.packageName);
                    result.put(app);
                }
            } catch (Exception ignored) { }
            return result.toString();
        }

        @JavascriptInterface
        public String getAppIcon(String packageName) {
            try {
                PackageManager pm = getPackageManager();
                Drawable drawable = pm.getApplicationIcon(packageName);
                int size = 96;
                Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(bitmap);
                drawable.setBounds(0, 0, size, size);
                drawable.draw(canvas);
                java.io.ByteArrayOutputStream output = new java.io.ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, output);
                bitmap.recycle();
                return "data:image/png;base64," + Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP);
            } catch (Exception ignored) {
                return "";
            }
        }

        @JavascriptInterface
        public String getBatteryInfo() {
            try {
                Intent batteryIntent = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                if (batteryIntent == null) return "{\"level\":-1,\"charging\":false}";
                int level = batteryIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int scale = batteryIntent.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                int status = batteryIntent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                int percent = (level >= 0 && scale > 0) ? Math.round(level * 100f / scale) : -1;
                boolean charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL;
                return "{\"level\":" + percent + ",\"charging\":" + charging + "}";
            } catch (Exception ignored) {
                return "{\"level\":-1,\"charging\":false}";
            }
        }

        @JavascriptInterface
        public boolean launchApp(String packageName) {
            try {
                Intent launch = getPackageManager().getLaunchIntentForPackage(packageName);
                if (launch == null) return false;
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(launch);
                return true;
            } catch (Exception ignored) {
                return false;
            }
        }
    }

    private void beginVoiceRecognition() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            deliverVoiceEvent("error", "На телефоне не найден сервис распознавания речи.");
            return;
        }
        try {
            if (speechRecognizer != null) speechRecognizer.destroy();
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            speechRecognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { deliverVoiceEvent("status", "Слушаю тебя…"); }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { deliverVoiceEvent("status", "Обрабатываю команду…"); }
                @Override public void onError(int error) {
                    String message = error == SpeechRecognizer.ERROR_NO_MATCH ? "Не расслышал. Попробуй ещё раз." :
                        error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ? "Нужно разрешить доступ к микрофону." :
                        "Не получилось распознать речь. Проверь микрофон и попробуй ещё раз.";
                    deliverVoiceEvent("error", message);
                }
                @Override public void onResults(Bundle results) {
                    ArrayList<String> matches = results == null ? null : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (matches != null && !matches.isEmpty()) deliverVoiceEvent("result", matches.get(0));
                    else deliverVoiceEvent("error", "Не расслышал команду. Попробуй ещё раз.");
                }
                @Override public void onPartialResults(Bundle partialResults) {
                    ArrayList<String> matches = partialResults == null ? null : partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (matches != null && !matches.isEmpty()) deliverVoiceEvent("partial", matches.get(0));
                }
                @Override public void onEvent(int eventType, Bundle params) { }
            });
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU");
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ru-RU");
            intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            speechRecognizer.startListening(intent);
        } catch (Exception e) {
            deliverVoiceEvent("error", "Не удалось запустить микрофон. Попробуй ещё раз.");
        }
    }

    private void deliverVoiceEvent(String type, String message) {
        runOnUiThread(() -> {
            if (web != null) {
                String js = "window.neonVoiceEvent && window.neonVoiceEvent(" + JSONObject.quote(type) + "," + JSONObject.quote(message) + ");";
                web.evaluateJavascript(js, null);
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_AUDIO_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) beginVoiceRecognition();
            else deliverVoiceEvent("error", "Разреши NEON OS использовать микрофон, чтобы говорить с помощником.");
        }
    }

    @Override
    public void onBackPressed() {
        if (web != null) {
            web.evaluateJavascript(
                "if (typeof closeTopScreen === 'function') { closeTopScreen(); }",
                null
            );
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
            speechRecognizer = null;
        }
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
            textToSpeech = null;
        }
        if (web != null) {
            web.removeJavascriptInterface("NeonAndroid");
            web.destroy();
        }
        super.onDestroy();
    }
}
